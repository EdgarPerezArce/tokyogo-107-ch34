

function Footer() {
    return (
        <div className="footer">
            <label>Edgar Perez</label>
        </div>
    );
}

export default Footer;