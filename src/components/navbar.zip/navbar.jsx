
import "./navbar.css";

function NavBar() {
    return (
        <div className='navbar'>
            menu here
        </div>
    );
}

export default NavBar;